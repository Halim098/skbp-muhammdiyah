@extends('layouts.admin')

@section('content')
    <h2>Welcome to the Admin Dashboard</h2>
@endsection